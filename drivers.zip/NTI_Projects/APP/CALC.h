

#ifndef CALC_H_
#define CALC_H_


s32 GET_NUM(u8 dig);

void CALC_Runnable(void);

void CALC_Init(void);


#endif /* CALC_H_ */
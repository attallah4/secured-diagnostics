

#include "StdTypes.h"
#include "DIO_Interface.h"
#include "LCD_Interface.h"
#include "Utils.h"
#include "SEV_SEG_Interface.h"


void COUNTER_Init(void)
{
	DIO_Init();
	LCD_Init();
	
}

void COUNTER_Runnable(void)
{
	static u16 i=0;
	for (u8 j=0;j<10;j++)
	{
		Segment_display(i);
	}
	i++;
	if (i==10000)
	{
		i=0;
	}
	
}


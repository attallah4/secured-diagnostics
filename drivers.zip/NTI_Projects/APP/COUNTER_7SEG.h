


#ifndef COUNTER_7SEG_H_
#define COUNTER_7SEG_H_

void COUNTER_Runnable(void);

void COUNTER_Init(void);



#endif /* COUNTER_7SEG_H_ */
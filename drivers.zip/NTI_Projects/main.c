#include "StdTypes.h"
#include "MemMap.h"
#include "Utils.h"
#include "SEV_SEG_Interface.h"
#include "DIO_Interface.h"
#include "LCD_Interface.h"
#include "Padel.h"
#include "KeyPad_Cfg.h"
#include "KeyPad_Interface.h"
#include "COUNTER_7SEG.h"
#include "EX_Interrupt_Interface.h"
#include "ADC_Interfaceh.h"
#include "CALC.h"
#include "Sensors_Interface.h"
#include "Sensors_Cfg.h"
#include "Hamoksha_Story.h"
#include "TIMER0_Interface.h"
#include "TIMER1_Interface.h"
#include "Servo_Interface.h"
#include "Timer1_Services.h"
#include "UART_Interface.h"
#include "SPI_Interface.h"
#include "I2C_Interface.h"


void LDR_LED(void);

volatile u8 flag_temp=1;
volatile u8 flag_ldr=1;

void set_ldr(void)
{
	flag_ldr=1;
}

void set_temp(void)
{
	flag_temp=1;
}

volatile ADC_Channel_type channel =CH_0;

volatile u8 flag_adc_ldr=0;
volatile u8 flag_adc_lm35=1;

volatile u16 ADC_READ_ldr=0;
volatile u16 TEMP_READ=0;
void adc_read_chain(void)
{
	if (flag_adc_ldr==0)
	{
		ADC_READ_ldr=ADC_16ReadADC();
		flag_adc_ldr=1;
		channel=CH_1;
		ADC_voidStartConversion(channel);
	}
	else if (flag_adc_lm35==0)
	{
		TEMP_READ=Temp_Read();
		flag_adc_lm35=1;
		channel=CH_0;
		ADC_voidStartConversion(channel);
	}
}


int main(void)
{
	DIO_Init();
	LCD_Init();
	//KEYPAD_Init();
	ADC_SetCallback(adc_read_chain);
	GIE_voidEnable();
	EXI_SetCallBack(EX_INT0,set_ldr);
	EXI_SetCallBack(EX_INT1,set_temp);
	EXI_Enable(EX_INT0);
	EXI_TriggerEdge(EX_INT0,RISING_EDGE);
	EXI_Enable(EX_INT1);
	EXI_TriggerEdge(EX_INT1,RISING_EDGE);
	ADC_Init(VREF_AVCC,ADC_SCALER_128);
	ADC_Chain(CH_0);
	
	
	while (1)
	{
		if ((TEMP_READ/10)>25)
		{
			DIO_WritePin(PIND2,HIGH);
			_delay_ms(1);
			DIO_WritePin(PIND2,LOW);
		}
		else
		{
			flag_temp=0;
		}
		
		if ((ADC_READ_ldr)>400)
		{
			DIO_WritePin(PIND3,HIGH);
			_delay_ms(1);
			DIO_WritePin(PIND3,LOW);
		}
		else
		{
			flag_ldr=0;
		}
		
		if (flag_adc_lm35)
		{
			if (flag_temp)
			{
				LCD_GoTo(1,0);
				LCD_WriteString("EX_Temp:");
				LCD_GoTo(1,8);
				LCD_WriteString("                      ");
				LCD_GoTo(1,8);
				LCD_WriteNumber(TEMP_READ/10);
				LCD_WriteChar('.');
				LCD_WriteNumber(TEMP_READ%10);
				LCD_WriteString("      ");
				//_delay_ms(100);
				LCD_GoTo(3,10);
			}
			else
			{
				LCD_GoTo(1,0);
				LCD_WriteString("Temp:");
				LCD_GoTo(1,5);
				LCD_WriteString("      ");
				LCD_GoTo(1,5);
				LCD_WriteNumber(TEMP_READ/10);
				LCD_WriteChar('.');
				LCD_WriteNumber(TEMP_READ%10);
				LCD_WriteString("      ");
				//_delay_ms(100);
				
			}
			flag_adc_lm35=0;
		}
		
		if (flag_adc_ldr)
		{
			if(flag_ldr)
			{
				LCD_GoTo(2,0);
				LCD_WriteString("EX_LDR:");
				LCD_WriteNumber(ADC_READ_ldr);
				LCD_WriteString("                ");
				LDR_LED();
			}
			else
			{
				LCD_GoTo(2,0);
				LCD_WriteString("LDR:");
				LCD_WriteNumber(ADC_READ_ldr);
				LCD_WriteString("                ");
				LDR_LED();
			}
			flag_adc_ldr=0;
		}
	}
}


void LDR_LED(void)
{
		if(ADC_READ_ldr<1023&&ADC_READ_ldr>768)
		{
			DIO_WritePin(PINB7,HIGH);
			DIO_WritePin(PINA4,LOW);
			DIO_WritePin(PINA5,LOW);
			DIO_WritePin(PINA6,LOW);
		}
		else if(ADC_READ_ldr<768&&ADC_READ_ldr>512)
		{
			DIO_WritePin(PINB7,LOW);
			DIO_WritePin(PINA4,HIGH);
			DIO_WritePin(PINA5,LOW);
			DIO_WritePin(PINA6,LOW);
		}
		else if(ADC_READ_ldr<512&&ADC_READ_ldr>256)
		{
			DIO_WritePin(PINB7,LOW);
			DIO_WritePin(PINA4,LOW);
			DIO_WritePin(PINA5,HIGH);
			DIO_WritePin(PINA6,LOW);
		}
		else if(ADC_READ_ldr>0)
		{
			DIO_WritePin(PINB7,LOW);
			DIO_WritePin(PINA4,LOW);
			DIO_WritePin(PINA5,LOW);
			DIO_WritePin(PINA6,HIGH);
		}
}
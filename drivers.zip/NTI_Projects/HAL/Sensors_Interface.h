

#ifndef SENSORS_INTERFACE_H_
#define SENSORS_INTERFACE_H_


u16 Temp_Read(void);




#endif /* SENSORS_INTERFACE_H_ */
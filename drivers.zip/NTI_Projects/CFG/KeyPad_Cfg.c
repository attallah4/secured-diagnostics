


#include "StdTypes.h"
#include "KeyPad_Cfg.h"

const u8 KeysArr[ROWS][COLS]={   {'+','=','0','C'},
								 {'-','3','2','1'},
								 {'*','6','5','4'},
								 {'/','9','8','7'}   };
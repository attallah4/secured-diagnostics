


#ifndef SENSORS_CFG_H_
#define SENSORS_CFG_H_


#define TEMP_CH CH_1

#define LDR_CH CH_0

#endif /* SENSORS_CFG_H_ */
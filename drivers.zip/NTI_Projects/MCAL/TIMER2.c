/*
 * TIMER2.c
 *
 * Created: 27/10/2023 10:57:45
 *  Author: Alahram
 */ 

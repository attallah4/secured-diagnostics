

#ifndef I2C_PRIVATE_H_
#define I2C_PRIVATE_H_



#define     I2C_SLAVE         0
#define     I2C_MASTER        1

#define     ENABLE            0
#define     DISABLE           1


/*        I2C Physical Pins */
#define       I2C_SCL          PINC0
#define       I2C_SDA          PINC1


#define       I2C_SC_ACK        0x08
#define       I2C_RSC_ACK       0x10
#define       I2C_MT_SLA_R_ACK  0x40
#define       I2C_MT_SLA_W_ACK  0x18
#define       I2C_MT_DATA_ACK   0x28
#define       I2C_MR_DATA_ACK   0x48
#define       I2C_SR_DATA_ACK   0x80



#endif /* I2C_PRIVATE_H_ */